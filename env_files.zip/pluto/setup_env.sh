#!/bin/bash

# Create symlinks in home directory if they don't exist
echo "Setting up environment symlinks..."

# Create .bashrc symlink - backup existing if needed
[ -e ~/.bashrc ] && mv ~/.bashrc ~/.bashrc.bck && echo "Backed up existing ~/.bashrc"
ln -s /sensei-fs/users/yizhouw/qd/pluto/.bashrc ~/.bashrc

# Create .ssh symlink - backup existing if needed
[ -e ~/.ssh ] && cp ~/.ssh ~/.ssh.bck && echo "Backed up existing ~/.ssh"
# ln -s /sensei-fs/users/yizhouw/qd/.ssh ~/.ssh && cp ~/.ssh.bck/* ~/.ssh/
cp /sensei-fs/users/yizhouw/qd/.ssh/{id_ed25519.pub,id_ed25519,id_rsa,id_rsa.pub,config} ~/.ssh/


# Create .tmux.conf symlink if it doesn't exist
[ ! -e ~/.tmux.conf ] && ln -s /sensei-fs/users/yizhouw/qd/pluto/.tmux.conf ~/.tmux.conf

# create .aws symlink if it doesn't exist
[ ! -e ~/.aws ] && ln -s /sensei-fs/users/yizhouw/qd/pluto/.aws ~/.aws

echo "Symlink setup complete!"