# ~/.bashrc: executed by bash(1) for non-login shells.
# see /usr/share/doc/bash/examples/startup-files (in the package bash-doc)
# for examples
# Enable color support for ls and grep
if [ -x /usr/bin/dircolors ]; then
    test -r ~/.dircolors && eval "$(dircolors -b ~/.dircolors)" || eval "$(dircolors -b)"
    alias ls='ls --color=auto'
    alias grep='grep --color=auto'
    alias fgrep='fgrep --color=auto'
    alias egrep='egrep --color=auto'
fi

# Colored GCC warnings and errors
export GCC_COLORS='error=01;31:warning=01;35:note=01;36:caret=01;32:locus=01:quote=01'


# Colorful prompt
# PS1='\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '

# Add some useful aliases for color
alias ll='ls -alF --color=auto'
alias la='ls -A --color=auto'
alias l='ls -CF --color=auto'

# Enable color in man pages
export LESS_TERMCAP_mb=$'\E[1;31m'     # begin blink
export LESS_TERMCAP_md=$'\E[1;36m'     # begin bold
export LESS_TERMCAP_me=$'\E[0m'        # reset bold/blink
export LESS_TERMCAP_so=$'\E[01;44;33m' # begin reverse video
export LESS_TERMCAP_se=$'\E[0m'        # reset reverse video
export LESS_TERMCAP_us=$'\E[1;32m'     # begin underline
export LESS_TERMCAP_ue=$'\E[0m'        # reset underline

export GEMINI_API_KEY=AIzaSyBmnUhOzTOruu7CPJkUR5afKfEs7W_ogMg

# If not running interactively, don't do anything
case $- in
    *i*) ;;
      *) return;;
esac

# don't put duplicate lines or lines starting with space in the history.
# See bash(1) for more options
HISTCONTROL=ignoreboth

# append to the history file, don't overwrite it
shopt -s histappend

# for setting history length see HISTSIZE and HISTFILESIZE in bash(1)
HISTSIZE=1000
HISTFILESIZE=2000

# check the window size after each command and, if necessary,
# update the values of LINES and COLUMNS.
shopt -s checkwinsize

# If set, the pattern "**" used in a pathname expansion context will
# match all files and zero or more directories and subdirectories.
#shopt -s globstar

# make less more friendly for non-text input files, see lesspipe(1)
[ -x /usr/bin/lesspipe ] && eval "$(SHELL=/bin/sh lesspipe)"

# set variable identifying the chroot you work in (used in the prompt below)
if [ -z "${debian_chroot:-}" ] && [ -r /etc/debian_chroot ]; then
    debian_chroot=$(cat /etc/debian_chroot)
fi

# set a fancy prompt (non-color, unless we know we "want" color)
case "$TERM" in
    xterm-color|*-256color) color_prompt=yes;;
esac

# uncomment for a colored prompt, if the terminal has the capability; turned
# off by default to not distract the user: the focus in a terminal window
# should be on the output of commands, not on the prompt
#force_color_prompt=yes

if [ -n "$force_color_prompt" ]; then
    if [ -x /usr/bin/tput ] && tput setaf 1 >&/dev/null; then
	# We have color support; assume it's compliant with Ecma-48
	# (ISO/IEC-6429). (Lack of such support is extremely rare, and such
	# a case would tend to support setf rather than setaf.)
	color_prompt=yes
    else
	color_prompt=
    fi
fi

if [ "$color_prompt" = yes ]; then
    PS1='${debian_chroot:+($debian_chroot)}\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '
else
    PS1='${debian_chroot:+($debian_chroot)}\u@\h:\w\$ '
fi
unset color_prompt force_color_prompt

# If this is an xterm set the title to user@host:dir
case "$TERM" in
xterm*|rxvt*)
    PS1="\[\e]0;${debian_chroot:+($debian_chroot)}\u@\h: \w\a\]$PS1"
    ;;
*)
    ;;
esac

# enable color support of ls and also add handy aliases
if [ -x /usr/bin/dircolors ]; then
    test -r ~/.dircolors && eval "$(dircolors -b ~/.dircolors)" || eval "$(dircolors -b)"
    alias ls='ls --color=auto'
    #alias dir='dir --color=auto'
    #alias vdir='vdir --color=auto'

    alias grep='grep --color=auto'
    alias fgrep='fgrep --color=auto'
    alias egrep='egrep --color=auto'
fi

# colored GCC warnings and errors
#export GCC_COLORS='error=01;31:warning=01;35:note=01;36:caret=01;32:locus=01:quote=01'

# some more ls aliases
alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'

# Add an "alert" alias for long running commands.  Use like so:
#   sleep 10; alert
alias alert='notify-send --urgency=low -i "$([ $? = 0 ] && echo terminal || echo error)" "$(history|tail -n1|sed -e '\''s/^\s*[0-9]\+\s*//;s/[;&|]\s*alert$//'\'')"'

# Alias definitions.
# You may want to put all your additions into a separate file like
# ~/.bash_aliases, instead of adding them here directly.
# See /usr/share/doc/bash-doc/examples in the bash-doc package.

if [ -f ~/.bash_aliases ]; then
    . ~/.bash_aliases
fi

# enable programmable completion features (you don't need to enable
# this, if it's already enabled in /etc/bash.bashrc and /etc/profile
# sources /etc/bash.bashrc).
if ! shopt -oq posix; then
  if [ -f /usr/share/bash-completion/bash_completion ]; then
    . /usr/share/bash-completion/bash_completion
  elif [ -f /etc/bash_completion ]; then
    . /etc/bash_completion
  fi
fi


# ================================================================
# True setup for personal information
# ================================================================
export sen=/sensei-fs/users/yizhouw/qd/
export senp=/sensei-fs/users/yizhouw/qd/pluto/

# >>> conda initialize >>>
# !! Contents within this block are managed by 'conda init' !!
__conda_setup="$('/sensei-fs/users/yizhouw/anaconda3/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
if [ $? -eq 0 ]; then
    eval "$__conda_setup"
else
    if [ -f "/sensei-fs/users/yizhouw/anaconda3/etc/profile.d/conda.sh" ]; then
        . "/sensei-fs/users/yizhouw/anaconda3/etc/profile.d/conda.sh"
    else
        export PATH="/sensei-fs/users/yizhouw/anaconda3/bin:$PATH"
    fi
fi
unset __conda_setup
# <<< conda initialize <<<

export p3='s3://phidias/dqh/'
s3s(){
    aws s3 $@ --profile sam
}

# set huggingface cache to /mnt/localssd/.cache
export HF_TOKEN='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'
export HF_HOME='/mnt/localssd/.cache/huggingface'

hgf_login() {
    huggingface-cli login --token $HF_TOKEN --add-to-git-credential
}
hff(){
    export HF_HUB_ENABLE_HF_TRANSFER=1
}

# set kaggle
# {"username":"qihuadong","key":"4444ce295a84ddbd21443b9f0e8137f8"}
export KAGGLE_USERNAME='qihuadong'
export KAGGLE_KEY='4444ce295a84ddbd21443b9f0e8137f8'

# wandb
export WANDB_API_KEY='b2cff88be717202a017073ef831b09fbdf47756b'
wdb_login(){
    wandb login --relogin $WANDB_API_KEY
}

# Enable color support
force_color_prompt=yes

# Define colors
BLACK='\[\033[0;30m\]'
RED='\[\033[0;31m\]'
GREEN='\[\033[0;32m\]'
YELLOW='\[\033[0;33m\]'
BLUE='\[\033[0;34m\]'
MAGENTA='\[\033[0;35m\]'
CYAN='\[\033[0;36m\]'
WHITE='\[\033[0;37m\]'
BOLD='\[\033[1m\]'
RESET='\[\033[0m\]'

# Define the prompt
# PS1="${GREEN}\u${WHITE}@${CYAN}\h ${YELLOW}\w ${MAGENTA}\$(parse_git_branch)${RESET}\$ "
parse_git_branch() {
    git branch 2>/dev/null | grep '\*' | sed 's/* //'
}
PS1="${GREEN}\u@${CYAN}\h ${MAGENTA}\$(parse_git_branch)\n${YELLOW}\w ${RESET}\$ "

zels(){
    zellij list-sessions
}
zea(){
    zellij attach $1
}
git_setup(){
    git config --global user.name "dddraxxx"
    git config --global user.email "dongqh078@gmail.com"
}
git_setup

link_config(){
    ln -sf $senp/.tmux.conf $senp/.bashrc $senp/.ssh $HOME
}

install_zellij(){
    curl -L https://raw.githubusercontent.com/dddraxxx/running_scripts/refs/heads/main/install_zellij.sh | bash
}
install_uv(){
    INSTALLER_NO_MODIFY_PATH=1 curl -LsSf https://astral.sh/uv/install.sh | sh
}
install_img2sixel(){
    git clone https://github.com/saitoha/libsixel.git
    cd libsixel
    ./configure
    make
    sudo make install
}

cur(){
    file=${1:-~/.bashrc}
    cursor -r $file
}
cod(){
    file=${1:-~/.bashrc}
    code -r $file
}

# python http server start in some dir
ser_htp(){
    # Start Python HTTP server on localhost with specified port (default 8000)
    # Usage: ser_htp [port]
    python3 -m http.server $@
}

cdd(){
    CUDA_VISIBLE_DEVICES=$1
    shift
    CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES $@
}
export PATH="$HOME/bin:$PATH"

# set alias for download github repo
rs_dl(){
    # git clone git@github.com:dddraxxx/VLAA-thinking.git
    # vlaa thinking data in $p3'/vlaa_thinking_data/'
    curl -sL https://raw.githubusercontent.com/dddraxxx/running_scripts/refs/heads/main/reason_synth.sh | bash
}
easy_dl(){
    git clone git@github.com:dddraxxx/EasyR1-private.git easyr1
    cd easyr1 && bash uv_pip.sh
}

occ_gpu(){
    curl -sL https://raw.githubusercontent.com/dddraxxx/running_scripts/refs/heads/main/gpu_mem_ploder.py | python
}

jread(){
    jq -C '.[]' $@ | less -R
}

dbg_py(){
    debugpy --listen 5678 --wait-for-client $@
}

if [ -z "$(git config --global --get credential.helper)" ]; then
    git config --global credential.helper store
fi
if zellij ls 2>&1 | grep -qi "no active"; then
    # zellij attach -c
    eval "$(zellij setup --generate-auto-start bash)"
fi

export PATH=~/.npm-global/bin:$PATH

# Generated for envman. Do not edit.
[ -s "$HOME/.config/envman/load.sh" ] && source "$HOME/.config/envman/load.sh"

export OPENROUTER_API_KEY=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

uva(){
    local dir="${1:-.}"
    local venv_path=$(find "$dir" -maxdepth 2 -type d -name ".venv" 2>/dev/null | head -n 1)
    if [ -n "$venv_path" ] && [ -f "$venv_path/bin/activate" ]; then
        source "$venv_path/bin/activate"
    else
        echo "No .venv found in $dir"
    fi
}
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion

. "$HOME/.local/bin/env"
